//gsoap ns service name: localtime
//gsoap ns service encoding: literal
//gsoap ns service namespace: http://www.alethea.net/webservices/
int ns__LocalTimeByZipCode(char *ZipCode, char **LocalTimeByZipCodeResult);
