//gsoap ck service name: ck
//gsoap ck service location: www.cs.fsu.edu/~engelen
//gsoap ck service namespace: urn:ck
int ck__demo(char **r);
