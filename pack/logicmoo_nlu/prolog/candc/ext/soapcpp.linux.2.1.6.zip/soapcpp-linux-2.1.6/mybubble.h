// See http://www.xmethods.com "mybubble" Company Profile service
typedef char *xsd__string;
int ns__getServiceResponsePublic(xsd__string serviceName, xsd__string inputText, xsd__string *_return);
