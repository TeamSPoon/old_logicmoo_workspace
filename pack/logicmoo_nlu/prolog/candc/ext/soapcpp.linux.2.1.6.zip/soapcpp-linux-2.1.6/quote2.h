/*	getQuote example with asynchronous SOAP messaging
*/
ns__getQuote(char *symbol, void dummy);
ns__getQuoteResponse(float result, void dummy);
