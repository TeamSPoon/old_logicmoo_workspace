int ns__getQuote(char *symbol, float *result);
