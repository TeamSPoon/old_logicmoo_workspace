typedef double xsd__double;
//gsoap ns service name: ssl
//gsoap ns service location: https://linprog1.cs.fsu.edu:18081
//gsoap ns service namespace: urn:ssl
int ns__add(xsd__double a, xsd__double b, xsd__double *result);
