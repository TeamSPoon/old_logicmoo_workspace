//gsoap ns service name: quote
//gsoap ns service location: http://services.xmethods.net/soap
//gsoap ns service namespace: urn:xmethods-delayed-quotes
int ns__getQuote(char *symbol, float &result);
